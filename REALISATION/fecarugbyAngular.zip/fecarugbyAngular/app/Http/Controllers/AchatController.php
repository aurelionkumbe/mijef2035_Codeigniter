<?php

namespace fecarugby\Http\Controllers;

use Illuminate\Http\Request;

use fecarugby\Http\Requests;

class AchatController extends Controller
{
    //
}
