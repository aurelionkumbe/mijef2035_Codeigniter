<?php

namespace fecarugby;

use Illuminate\Database\Eloquent\Model;

class Achat extends Model
{
    //
}
