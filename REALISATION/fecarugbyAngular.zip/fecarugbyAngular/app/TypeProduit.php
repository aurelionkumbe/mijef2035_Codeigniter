<?php

namespace fecarugby;

use Illuminate\Database\Eloquent\Model;

class TypeProduit extends Model {

    protected $table = 'type_produit';
    protected $guarded = ['id'];

    //
}
