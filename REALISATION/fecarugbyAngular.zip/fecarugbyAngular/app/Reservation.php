<?php

namespace fecarugby;

use Illuminate\Database\Eloquent\Model;

class Reservation extends Model
{
    //
}
