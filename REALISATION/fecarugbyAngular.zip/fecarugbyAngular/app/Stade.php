<?php

namespace fecarugby;

use Illuminate\Database\Eloquent\Model;

class Stade extends Model
{
    //
}
