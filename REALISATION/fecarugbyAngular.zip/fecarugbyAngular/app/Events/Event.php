<?php

namespace fecarugby\Events;

abstract class Event
{
    //
}
