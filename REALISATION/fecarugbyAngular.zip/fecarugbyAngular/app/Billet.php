<?php

namespace fecarugby;

use Illuminate\Database\Eloquent\Model;

class Billet extends Model
{
    //
}
