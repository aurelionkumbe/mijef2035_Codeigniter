<?php

namespace fecarugby;

use Illuminate\Database\Eloquent\Model;

class Admin extends Model
{
    //
}
