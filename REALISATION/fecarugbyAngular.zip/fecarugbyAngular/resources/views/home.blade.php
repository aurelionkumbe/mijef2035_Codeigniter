@extends('layouts.app')

@section('header')


@endsection

@section('content')

<div class="content">

    <div class="row" style="padding-top: 50px;" ui-view="">

    </div>



</div>

@endsection

@section('footer')
@endsection