;<?php return; ?>
[SQL]
host = localhost
user = root
password = 
dbname = kwatahelyfdigit
