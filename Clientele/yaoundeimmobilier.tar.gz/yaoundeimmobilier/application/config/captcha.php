<?php
// BotDetect PHP Captcha configuration options

$config = array(
    // Captcha configuration for example page
    'ExampleCaptcha' => array(
        'UserInputID' => 'CaptchaCode',
        'ImageWidth' => 250,
        'ImageHeight' => 50,
    ),

);