<address>
    <strong>YaoundéImmobilier</strong><br>
    2, rue, Liberté Mimboman<br>
    BP 4184 Yaoundé<br><br>
    <span title="Phone 1"><i class="fa fa-envelope"></i>&nbsp;</span> m_ithra@yahoo.fr <br>
    <span title="Phone 1"><i class="fa fa-mobile-phone"></i>&nbsp;</span> (237) 663 975 836 <br>
    <span title="Phone 2"><i class="fa fa-mobile-phone"></i>&nbsp;</span> (237) 691 500 645 <br>
    <span title="Phone Whatsapp"><i class="fa fa-whatsapp"></i></span> (237) 672 982 484
</address>