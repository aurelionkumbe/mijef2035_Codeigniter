<script src="<?= base_url('js/bootstrap.min.js')?>"></script>
<script src="<?= base_url('js/jquery.prettyPhoto.js')?>"></script>
<script src="<?= base_url('js/main.js')?>"></script>

