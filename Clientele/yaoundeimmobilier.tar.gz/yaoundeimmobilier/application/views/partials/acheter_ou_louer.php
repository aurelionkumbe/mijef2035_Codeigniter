<div class="w3-container">

    <div class="w3-row">
        <div class="w3-col m2 l2">
            &nbsp;
        </div>
        <div class="w3-col m4 l4">
            <div id="je-veux-louer" link="location" class="veux w3-card-4 test" style="width:92%;max-width:300px;">
                <img class="img-choix" src="<?php echo base_url('images/appart_a_louer.png')?>"  alt="Avatar" style="width:100%;opacity:0.85">
                <div class="w3-container text-center">
                    <h4><b>Je veux louer</b></h4>
                    <p>bureau, appartement, studio, ...</p>
                </div>
            </div>
        </div>
        <div class="w3-col m4 l4">
            <div id="je-veux-acheter" link="achat" class="veux w3-card-4 test" style="width:92%;max-width:300px;">
                <img src="<?php echo base_url('images/maison_a_vendre.jpg')?>" alt="Avatar" style="width:100%;opacity:0.85">
                <div class="w3-container text-center">
                    <h4><b>Je veux acheter</b></h4>
                    <p>maison, terrain titré, ...</p>
                </div>
            </div>
        </div>
        <div class="w3-col m2 l3">
            &nbsp;
        </div>
    </div>

</div>