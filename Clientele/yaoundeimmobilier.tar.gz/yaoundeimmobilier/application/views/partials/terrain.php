<?php include_once 'appart.php'?>
<!--div class="panel-group" id="accordion1" role="tablist" aria-multiselectable="true" >
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingOne">
      <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
            Centre ville
        </a>
      </h4>
    </div>
    <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
      <div class="panel-body" page="centre-ville.html">
          <?php include_once "terrains/centre-ville.html"?>
      </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingTwo">
      <h4 class="panel-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
            AXE YAOUNDE-route ouest cameroun
        </a>
      </h4>
    </div>
    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
      <div class="panel-body">
          <?php include_once "terrains/axe-yaounde-route-ouest-cameroun.html"?>
      </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="headingThree">
      <h4 class="panel-title">
        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
            Bankolo  fébé  Nkolbisson
        </a>
      </h4>
    </div>
    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
      <div class="panel-body">
          <?php include_once "terrains/bankolo--febe--nkolbisson.html"?>

      </div>
    </div>
  </div>
    <div class="panel panel-default">
        <div class="panel-heading" role="tab" id="heading4">
            <h4 class="panel-title">
                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse4" aria-expanded="false" aria-controls="collapse4">
                    Axe Yaoundé - Est-cameroun
                </a>
            </h4>
        </div>
        <div id="collapse4" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading4">
            <div class="panel-body" link="axe-yaounde---est-cameroun.html">
                <?php include_once "terrains/axe-yaounde---est-cameroun.html"?>

            </div>
        </div>
    </div>
    <div class="panel panel-default">
        <div class="panel-heading" role="tab" id="heading5">
            <h4 class="panel-title">
                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse5" aria-expanded="false" aria-controls="collapse5">
                    Axe yaoundé- route sud cameroun
                </a>
            </h4>
        </div>
        <div id="collapse5" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading5">
            <div class="panel-body" link="axe-yaounde--route-sud-cameroun.html">
                <?php include_once "terrains/axe-yaounde--route-sud-cameroun.html"?>

            </div>
        </div>
    </div>

    <div class="panel panel-default">
        <div class="panel-heading" role="tab" id="heading6">
            <h4 class="panel-title">
                <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse6" aria-expanded="false" aria-controls="collapse6">
                    Axe Yaoundé - route douala
                </a>
            </h4>
        </div>
        <div id="collapse6" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading6">
            <div class="panel-body" link="axe-yaounde--route-douala.html">
                <?php include_once "terrains/axe-yaounde--route-douala.html" ?>
            </div>
        </div>
    </div>


</div-->

<br><br>

<h3 class="w3-card-2 w3-padding w3-yellow ">TOUS LES JOURS, NOUS ORGANISONS DEUX DESCENTES SUR LES DIVERS
    SITES<br /></h3>


<div class="panel-group" id="accordion2" role="tablist" aria-multiselectable="true" >
    <div class="panel panel-default">
        <div class="panel panel-info">
            <div class="panel-heading" role="tab" id="heading7">
                <h4 class="panel-title">
                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion2" href="#collapse7" aria-expanded="false" aria-controls="collapse7">
                        Conseils d'avant achat
                    </a>
                </h4>
            </div>
            <div id="collapse7" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading7">
                <div class="panel-body" link="conseils-davant-achat.html">
                    <?php include_once "terrains/conseils-davant-achat.html"?>
                </div>
            </div>
        </div>
        <div class="panel panel-info">
            <div class="panel-heading" role="tab" id="heading8">
                <h4 class="panel-title">
                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion2" href="#collapse8" aria-expanded="false" aria-controls="collapse8">
                        Avertissement
                    </a>
                </h4>
            </div>
            <div id="collapse8" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading8">
                <div class="panel-body" link="conseils-davant-achat.html">
                    <?php include_once "terrains/avertissement.html"?>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="application/javascript">


</script>