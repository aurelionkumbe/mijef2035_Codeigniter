todo

// controler l uncite du nemro de tel
// filter var sur lemail et validation des autre champ


// tres important changement a operer dans taskman

les actions (todo) et les travaux deja effectués ne differ vraiment en rien
il dont fusionner les deux tables actions et travaux,
une action est desormais reconnues par son attribue < resolue (ou  solved)> avec une value a 0
un travail (deja effectue) est desormais reconnues par son attribue < resolue (ou  solved)> avec une value a 1

la tache qui en resulte de la fusion des tables actions et travaux est appelle taches