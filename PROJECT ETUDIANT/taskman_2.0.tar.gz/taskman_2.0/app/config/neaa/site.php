<?php	if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['siteName'] = "no-name";
$config['title'] = 'Welcome';
$config['author'] = 'human';
$config['keywords'] = 'surf';
$config['description'] = 'a website';
$config['language'] = 'en';