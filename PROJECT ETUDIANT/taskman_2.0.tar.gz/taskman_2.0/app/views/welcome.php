<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">

	
</head>
<body>

<div id="container">
	<h1>Welcome to CodeIgniter!</h1>

	<h1 class="page-heading">STARTER KIT for codeigniter, created by NKUMBE AURELIEN</h1>
   

   
</body>
</html>