jConfirm
========

jQuery confirmation plugin

Demo / Documentation:
http://flwebsites.biz/jConfirm/
