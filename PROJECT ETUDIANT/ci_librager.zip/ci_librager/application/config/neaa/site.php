<?php	if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['siteName'] = "Librager";
$config['title'] = 'Bienvenue';
$config['author'] = 'nkumbe enongene astrid aurelien';
$config['keywords'] = 'sell, book,';
$config['description'] = 'this application is a library manager, it can controle selling , loaning of book. registred users have a board were they can read book online and command books';
$config['language'] = 'fr,en';

// 2 templates deja disponible : html5boilerplate et googlestarterkit
$config['default_template'] = 'html5boilerplate';


// salt de hashage de mot de passe
$config['salt_prefixe'] = 'ghl&/ !uso*Ä ÖÜid gfr-. dsf23 4.-"(! ]¼r#-+#';
$config['salt_suffixe'] = 'ukm3ghl&/ ghl&/ !!sdg² ³¼ko02ghl&/ !97Ä_#ghl&/ !*Ä Öghl&/ ! 4.-"(ghlghl&/ !';


