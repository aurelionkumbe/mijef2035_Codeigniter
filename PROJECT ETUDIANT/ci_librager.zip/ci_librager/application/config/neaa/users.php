<?php	if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$config['guest_level'] = 0;
$config['custumer_level'] = 1;
$config['vip_custumer_level'] = 2;

$config['_level'] = 5;
$config['admin_level'] = 5;

