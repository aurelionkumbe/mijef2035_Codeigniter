<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<footer id="footer" class="w3-container w3-theme w3-padding-jumbo" >
    <div class="text-center"> Copyright &copy; 2015 , Projet programmation web , <a href="contact.html">contacter les membres</a></div>
</footer>