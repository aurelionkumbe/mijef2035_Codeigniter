<div class="navbar navbar-inverse navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?=site_url('admin/dashboard')?>">
                        <span class="mif-library mif-2x fg-green"></span>
                        <?='Librager'?></a>
                </div>
                <ul class="navbar-nav navbar-right" style="list-style: none">
                    <li>
                        <a href="<?=site_url('admin/logout')?>" class="btn w3-btn bg-red"><span class="mif-switch mif-2x"></span>&nbsp;Deconnexion</a>
                    </li>
                </ul>
            </div><!-- /.container -->
        </div>
