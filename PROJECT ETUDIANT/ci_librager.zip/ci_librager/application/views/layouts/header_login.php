<div class="navbar navbar-inverse navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?=site_url('books')?>">
                        <span class="mif-library mif-2x w3-text-green"></span>
                        Librager</a>
                </div>
                <ul hidden class="nav navbar-nav navbar-right">
                    <li id="fat-menu" class="dropdown">
                        <a href="javascript:void(0)" class="btn w3-btn w3-green ">Creer un compte</a>
                    </li>
                </ul>

               

            </div><!-- /.container -->
        </div>
