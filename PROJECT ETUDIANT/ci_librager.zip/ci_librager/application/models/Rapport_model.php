<?php

/**
 * Created by PhpStorm.
 * User: aurelio
 * Date: 23/03/16
 * Time: 18:34
 */
include_once '../libs/PDO/Db.class.php';

class Rapport_model extends NEAA_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load();

    }

    public function insertPersonne($data){

    }

    public function insertRapport($data){

    }

    public function insertTache($data){

    }

    public function insertFonction($data){

    }


    public function insertProbleme($data){

    }


    public function insertEntreprise($data){

    }

    public function insertAction($data){


    }
}