TODO: controler le telephone en numerique
TODO: generer un matricule qui lui permettra de voter 
TODO: Faire slider pour faire defiler les differents candidats

TODO: prevoir un icon a cote des champ password pour affiche le contenue lorsqu maintient le clique dessus
TODO refaire le fonction gen_mdp en gen_matricule(cni)


--------------extension futur apres l iai ---------------------------

TODO: le candidat aura droit a un expace membre pour mettre a jour sa vitrine de campagne

