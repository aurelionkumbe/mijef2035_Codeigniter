/**
 * Created by nkaurelien on 08/02/17.
 */
var AFTER_COUNTER_REDIRECT_TO = "/index.php/home/winner";
var DATE_DE_FIN_DES_ELECTIONS = new Date(2017, 11, 16, 14, 00  );
