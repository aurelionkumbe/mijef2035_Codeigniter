<aside class="menadmin col-md-2">
    <nav class=" navbar navbar-text ">
        <ul class="navbar-nav nav nav-pills">
            <li><a href="<?=base_url('index.php/admin/candidat')?>">Candidats</a></li>
            <li><a href="<?=base_url('index.php/admin/electeur')?>">Electeurs</a></li>
            <li style="display: none;"><a href="<?='#' //base_url('index.php/admin/setting')?>">setting</a></li>
        </ul>
    </nav>
</aside>