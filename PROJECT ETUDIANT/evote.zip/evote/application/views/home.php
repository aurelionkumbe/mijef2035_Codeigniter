<?php include_once 'partial/head.php' ?>
<?php include_once 'partial/header.php' ?>

<div id="middle" class="middle row">
    <section class="col-md-8 col-md-offset-2">
        <h1 CLASS="text-center text-muted" style="font-size: 80px;">WELCOME</h1>
    </section>
</div>

<?php include_once 'partial/footer.php' ?>
<?php include_once 'partial/foot.php' ?>