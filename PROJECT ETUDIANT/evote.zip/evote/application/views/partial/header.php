
<?= (isset($activeMenu) && ($activeMenu == '')) ? 'active' : '';  ?>
<header id="header" class="row">
    <div class="container">

        <div class=" col-md-12">
            <div class="col-md-2 col-md-offset-5 text-center">
                <img id="logo" src="<?=base_url('images/logo.png')?>" class="img-responsive">
            </div>
        </div>
    </div>

</header>