<p>&nbsp;</p>

<footer id="footer" class="row">
    <div class="container">
        <div class="col-md-12">
            <p class="text-center" style="color : #ccc;;">copyright &copy; IAI-Douala 2015 , <a href="<?= base_url('index.php/home/author') ?>"> Contact Authors</a></p>
        </div>
        <!-- /.col-md-12 -->
    </div>
</footer>